通过ansible-playbook，以源码编译方式部署nginx
